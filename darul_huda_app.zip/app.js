let students=[
{id:1,name:"Yusuf Hussain"},
{id:2,name:"Hussain Ansari"}
];

function render(){
let html="";
students.forEach(s=>{
html+=`<div class='card'>${s.name}</div>`;
});
document.getElementById("students").innerHTML=html;
}
render();

function save(){
alert("Saved");
}
